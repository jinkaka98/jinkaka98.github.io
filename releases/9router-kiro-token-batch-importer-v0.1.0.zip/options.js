import { DEFAULT_SETTINGS } from "./lib/defaults.js";
import { getSettings, saveSettings } from "./lib/storage.js";

const baseUrl = document.querySelector("#baseUrl");
const allowedUrlPattern = document.querySelector("#allowedUrlPattern");
const providerPath = document.querySelector("#providerPath");
const autoNavigateToProvider = document.querySelector("#autoNavigateToProvider");
const stepTimeoutMs = document.querySelector("#stepTimeoutMs");
const betweenItemsDelayMs = document.querySelector("#betweenItemsDelayMs");
const retryLimit = document.querySelector("#retryLimit");
const pauseOnFailure = document.querySelector("#pauseOnFailure");
const selectorOverrides = document.querySelector("#selectorOverrides");
const saveButton = document.querySelector("#saveButton");
const resetButton = document.querySelector("#resetButton");
const optionsMessage = document.querySelector("#optionsMessage");

function renderSettings(settings) {
  baseUrl.value = settings.baseUrl;
  allowedUrlPattern.value = settings.allowedUrlPattern;
  providerPath.value = settings.providerPath || DEFAULT_SETTINGS.providerPath;
  autoNavigateToProvider.checked = settings.autoNavigateToProvider !== false;
  stepTimeoutMs.value = String(settings.stepTimeoutMs);
  betweenItemsDelayMs.value = String(settings.betweenItemsDelayMs);
  retryLimit.value = String(settings.retryLimit);
  pauseOnFailure.checked = Boolean(settings.pauseOnFailure);
  selectorOverrides.value = JSON.stringify(settings.selectorOverrides || {}, null, 2);
}

async function loadSettings() {
  const settings = await getSettings();
  renderSettings(settings);
}

async function handleSave() {
  optionsMessage.textContent = "";

  try {
    const parsedOverrides = selectorOverrides.value.trim()
      ? JSON.parse(selectorOverrides.value)
      : {};

    const settings = {
      baseUrl: baseUrl.value.trim(),
      allowedUrlPattern: allowedUrlPattern.value.trim(),
      providerPath: providerPath.value.trim() || DEFAULT_SETTINGS.providerPath,
      autoNavigateToProvider: autoNavigateToProvider.checked,
      stepTimeoutMs: Number(stepTimeoutMs.value),
      betweenItemsDelayMs: Number(betweenItemsDelayMs.value),
      retryLimit: Number(retryLimit.value),
      pauseOnFailure: pauseOnFailure.checked,
      selectorOverrides: parsedOverrides
    };

    await saveSettings(settings);
    optionsMessage.textContent = "Settings saved.";
  } catch (error) {
    optionsMessage.textContent = error.message;
  }
}

async function handleReset() {
  await saveSettings(DEFAULT_SETTINGS);
  renderSettings(DEFAULT_SETTINGS);
  optionsMessage.textContent = "Default settings restored.";
}

saveButton.addEventListener("click", handleSave);
resetButton.addEventListener("click", handleReset);

loadSettings().catch((error) => {
  optionsMessage.textContent = error.message;
});
