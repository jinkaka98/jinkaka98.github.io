import {
  MESSAGE_TYPES,
  SESSION_TERMINAL_STATUSES
} from "./lib/constants.js";
import { parseCredentialLines } from "./lib/parsing.js";
import { DEFAULT_SETTINGS } from "./lib/defaults.js";
import { getSettings, getState, saveSettings, setDraftInput } from "./lib/storage.js";

const credentialInput = document.querySelector("#credentialInput");
const credentialCount = document.querySelector("#credentialCount");
const sessionStatus = document.querySelector("#sessionStatus");
const queuedCount = document.querySelector("#queuedCount");
const successCount = document.querySelector("#successCount");
const failedCount = document.querySelector("#failedCount");
const currentItem = document.querySelector("#currentItem");
const messageBox = document.querySelector("#messageBox");
const resultCount = document.querySelector("#resultCount");
const resultsList = document.querySelector("#resultsList");
const historyList = document.querySelector("#historyList");
const clearHistoryButton = document.querySelector("#clearHistoryButton");
const baseUrlInput = document.querySelector("#baseUrlInput");
const saveEndpointButton = document.querySelector("#saveEndpointButton");
const checkEndpointButton = document.querySelector("#checkEndpointButton");
const endpointStatus = document.querySelector("#endpointStatus");
const toggleImportButton = document.querySelector("#toggleImportButton");
const clearInputButton = document.querySelector("#clearInputButton");
const openOptions = document.querySelector("#openOptions");

const CREDIT_ID = "xixeroCredit";
const CREDIT_TEXT = "Copyright (c) XixeroLabs";
const CREDIT_URL = "https://jinkaka98.github.io/";
let restoringCredit = false;

function buildCreditLabel() {
  const footer = document.createElement("footer");
  const credit = document.createElement("a");

  footer.className = "credit-footer";
  footer.dataset.creditOwner = "XixeroLabs";
  footer.setAttribute("aria-label", "Copyright XixeroLabs");

  credit.id = CREDIT_ID;
  credit.href = CREDIT_URL;
  credit.target = "_blank";
  credit.rel = "noopener noreferrer";
  credit.dataset.creditOwner = "XixeroLabs";
  credit.textContent = CREDIT_TEXT;

  footer.appendChild(credit);
  return footer;
}

function ensureCreditLabel({ warn = false } = {}) {
  if (restoringCredit) {
    return;
  }

  restoringCredit = true;

  try {
    const shell = document.querySelector(".shell") || document.body;
    let credit = document.querySelector(`#${CREDIT_ID}`);
    let restored = false;

    if (!credit) {
      const footer = buildCreditLabel();
      shell.appendChild(footer);
      credit = footer.querySelector(`#${CREDIT_ID}`);
      restored = true;
    }

    if (credit.textContent.trim() !== CREDIT_TEXT) {
      credit.textContent = CREDIT_TEXT;
      restored = true;
    }

    if (credit.getAttribute("href") !== CREDIT_URL) {
      credit.setAttribute("href", CREDIT_URL);
      restored = true;
    }

    if (credit.getAttribute("target") !== "_blank") {
      credit.setAttribute("target", "_blank");
      restored = true;
    }

    if (credit.getAttribute("rel") !== "noopener noreferrer") {
      credit.setAttribute("rel", "noopener noreferrer");
      restored = true;
    }

    const footer = credit.closest(".credit-footer") || credit.parentElement;

    if (footer) {
      footer.classList.add("credit-footer");
      footer.dataset.creditOwner = "XixeroLabs";
      footer.setAttribute("aria-label", "Copyright XixeroLabs");
    }

    credit.dataset.creditOwner = "XixeroLabs";

    if (restored && warn) {
      messageBox.textContent = "Credit XixeroLabs dipulihkan otomatis.";
    }
  } finally {
    restoringCredit = false;
  }
}

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      const error = chrome.runtime.lastError;

      if (error) {
        reject(new Error(error.message));
        return;
      }

      resolve(response);
    });
  });
}

function normalizeBaseUrl(value) {
  const parsed = new URL(String(value || "").trim());
  parsed.pathname = "";
  parsed.search = "";
  parsed.hash = "";
  return parsed.toString().replace(/\/$/, "");
}

function allowedPatternFromBaseUrl(baseUrl) {
  const parsed = new URL(baseUrl);
  return `${parsed.protocol}//${parsed.host}/*`;
}

function setEndpointStatus(message, variant = "") {
  endpointStatus.textContent = message;
  endpointStatus.classList.toggle("ok", variant === "ok");
  endpointStatus.classList.toggle("fail", variant === "fail");
}

async function fetchWithTimeout(url, timeoutMs = 3500) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      method: "GET",
      cache: "no-store",
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeout);
  }
}

async function ensureHostPermissionFromUserGesture() {
  const settings = await getSettings();
  const origin = allowedPatternFromBaseUrl(settings.baseUrl);
  const permissionRequest = { origins: [origin] };
  const hasPermission = await chrome.permissions.contains(permissionRequest);

  if (hasPermission) {
    return;
  }

  const granted = await chrome.permissions.request(permissionRequest);

  if (!granted) {
    throw new Error(`Host permission ditolak untuk ${origin}`);
  }
}

function updateCredentialCount() {
  const total = parseCredentialLines(credentialInput.value).length;
  credentialCount.textContent = `${total} token siap diproses`;
}

function renderResults(results) {
  resultCount.textContent = String(results.length);
  resultsList.textContent = "";

  if (!results.length) {
    const empty = document.createElement("li");
    empty.textContent = "Belum ada hasil import.";
    resultsList.appendChild(empty);
    return;
  }

  results
    .slice()
    .reverse()
    .slice(0, 8)
    .forEach((result) => {
      const item = document.createElement("li");
      item.className = result.status === "success" ? "result-success" : "result-failed";

      const topline = document.createElement("div");
      topline.className = "result-topline";

      const label = document.createElement("strong");
      label.textContent = result.credentialPreview || "";

      const status = document.createElement("span");
      status.textContent = result.status;

      const message = document.createElement("div");
      message.textContent = result.message;

      topline.append(label, status);
      item.append(topline, message);
      resultsList.appendChild(item);
    });
}

function formatTime(value) {
  if (!value) {
    return "";
  }

  try {
    return new Date(value).toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  } catch {
    return "";
  }
}

function renderHistory(history) {
  historyList.textContent = "";

  if (!history.length) {
    const empty = document.createElement("li");
    empty.textContent = "Belum ada log.";
    historyList.appendChild(empty);
    return;
  }

  history.slice(0, 20).forEach((entry) => {
    const item = document.createElement("li");
    const topline = document.createElement("div");
    topline.className = "history-topline";

    const level = document.createElement("span");
    level.className = `history-level ${entry.level || "info"}`;
    level.textContent = entry.level || "info";

    const time = document.createElement("span");
    time.className = "muted";
    time.textContent = formatTime(entry.createdAt);

    const message = document.createElement("div");
    message.textContent = entry.message || "";

    const details = document.createElement("div");
    details.className = "history-detail";
    const detailParts = [];

    if (entry.details?.credentialPreview) {
      detailParts.push(`token: ${entry.details.credentialPreview}`);
    }

    if (entry.details?.attempt) {
      detailParts.push(`attempt: ${entry.details.attempt}`);
    }

    if (entry.details?.targetUrl) {
      detailParts.push(`url: ${entry.details.targetUrl}`);
    }

    details.textContent = detailParts.join(" | ");

    topline.append(level, time);
    item.append(topline, message);

    if (details.textContent) {
      item.appendChild(details);
    }

    historyList.appendChild(item);
  });
}

function renderState(state) {
  const { draftInput, queue, results, history, session, settings } = state;

  if (document.activeElement !== credentialInput) {
    credentialInput.value = draftInput || "";
  }

  if (document.activeElement !== baseUrlInput) {
    baseUrlInput.value = settings.baseUrl || DEFAULT_SETTINGS.baseUrl;
  }

  updateCredentialCount();

  sessionStatus.textContent = session.status;
  queuedCount.textContent = String(queue.filter((item) => item.status === "queued").length);
  successCount.textContent = String(results.filter((item) => item.status === "success").length);
  failedCount.textContent = String(results.filter((item) => item.status === "failed").length);

  const currentPreview = session.currentCredentialPreview;

  if (currentPreview) {
    currentItem.textContent = `Sedang diproses: ${currentPreview}`;
  } else if (SESSION_TERMINAL_STATUSES.has(session.status)) {
    currentItem.textContent = "Tidak ada item aktif.";
  } else {
    currentItem.textContent = "Menunggu item aktif.";
  }

  messageBox.textContent = session.currentError || "";
  renderResults(results);
  renderHistory(history || []);

  const isRunning = session.status === "running";
  const isStopping = session.status === "stopping";
  const isBusy = isRunning || isStopping;

  toggleImportButton.textContent = isBusy ? "Stop Import" : "Start Import";
  toggleImportButton.classList.toggle("danger", isBusy);
  toggleImportButton.classList.toggle("primary", !isBusy);
  toggleImportButton.disabled = false;
}

async function refresh() {
  const state = await getState();
  renderState(state);
}

async function handleStart() {
  ensureCreditLabel({ warn: true });
  messageBox.textContent = "";

  const rawInput = credentialInput.value;
  const credentials = parseCredentialLines(rawInput);

  if (!credentials.length) {
    messageBox.textContent = "Masukkan minimal satu refresh token valid.";
    return;
  }

  await setDraftInput(rawInput);

  try {
    await ensureHostPermissionFromUserGesture();

    const response = await sendMessage({
      type: MESSAGE_TYPES.START_IMPORT,
      payload: { credentials }
    });

    if (!response?.ok) {
      messageBox.textContent = response?.error || "Gagal memulai import.";
      return;
    }

    await refresh();
  } catch (error) {
    messageBox.textContent = error.message;
  }
}

async function handleSaveEndpoint({ silent = false } = {}) {
  try {
    const currentSettings = await getSettings();
    const baseUrl = normalizeBaseUrl(baseUrlInput.value || DEFAULT_SETTINGS.baseUrl);

    await saveSettings({
      ...currentSettings,
      baseUrl,
      allowedUrlPattern: allowedPatternFromBaseUrl(baseUrl)
    });

    baseUrlInput.value = baseUrl;

    if (!silent) {
      setEndpointStatus(`Endpoint disimpan: ${baseUrl}`, "ok");
    }

    return baseUrl;
  } catch (error) {
    setEndpointStatus(`Endpoint tidak valid: ${error.message}`, "fail");
    throw error;
  }
}

async function handleCheckEndpoint() {
  checkEndpointButton.disabled = true;
  setEndpointStatus("Mengecek endpoint...", "");

  try {
    const baseUrl = await handleSaveEndpoint({ silent: true });
    await ensureHostPermissionFromUserGesture();
    const response = await fetchWithTimeout(baseUrl);

    if (response.ok || response.status < 500) {
      setEndpointStatus(`Tersedia: ${baseUrl}`, "ok");
      return;
    }

    setEndpointStatus(`Merespons error ${response.status}: ${baseUrl}`, "fail");
  } catch (error) {
    const message = error.name === "AbortError"
      ? "timeout"
      : error.message;
    setEndpointStatus(`Tidak tersedia: ${message}`, "fail");
  } finally {
    checkEndpointButton.disabled = false;
  }
}

async function handleStop() {
  try {
    await sendMessage({ type: MESSAGE_TYPES.STOP_IMPORT });
    await refresh();
  } catch (error) {
    messageBox.textContent = error.message;
  }
}

async function handleToggleImport() {
  const state = await getState();

  if (state.session.status === "running" || state.session.status === "stopping") {
    await handleStop();
    return;
  }

  await handleStart();
}

async function handleClearInput() {
  credentialInput.value = "";
  updateCredentialCount();
  await setDraftInput("");
  messageBox.textContent = "";
  credentialInput.focus();
}

async function handleClearHistory() {
  const response = await sendMessage({ type: MESSAGE_TYPES.CLEAR_HISTORY });

  if (!response?.ok) {
    messageBox.textContent = response?.error || "Gagal menghapus log.";
    return;
  }

  await refresh();
}

credentialInput.addEventListener("input", async () => {
  updateCredentialCount();
  await setDraftInput(credentialInput.value);
});

toggleImportButton.addEventListener("click", handleToggleImport);
saveEndpointButton.addEventListener("click", () => {
  handleSaveEndpoint().catch(() => {});
});
checkEndpointButton.addEventListener("click", () => {
  handleCheckEndpoint().catch(() => {});
});
clearInputButton.addEventListener("click", () => {
  handleClearInput().catch((error) => {
    messageBox.textContent = error.message;
  });
});
clearHistoryButton.addEventListener("click", () => {
  handleClearHistory().catch((error) => {
    messageBox.textContent = error.message;
  });
});
openOptions.addEventListener("click", () => chrome.runtime.openOptionsPage());

ensureCreditLabel();

const creditObserver = new MutationObserver(() => {
  ensureCreditLabel({ warn: true });
});

creditObserver.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

setInterval(() => {
  ensureCreditLabel({ warn: true });
}, 2000);

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === MESSAGE_TYPES.SESSION_UPDATE) {
    refresh().catch(() => {});
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") {
    return;
  }

  if (changes.session || changes.queue || changes.results || changes.history || changes.draftInput) {
    refresh().catch(() => {});
  }
});

refresh().catch((error) => {
  messageBox.textContent = error.message;
});

getSettings()
  .then((settings) => {
    baseUrlInput.value = settings.baseUrl || DEFAULT_SETTINGS.baseUrl;
  })
  .catch((error) => {
    setEndpointStatus(error.message, "fail");
  });
