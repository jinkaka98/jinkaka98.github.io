(function initialize9RouterImporter() {
  if (globalThis.__nineRouterApiKeyImporterLoaded) {
    return;
  }

  globalThis.__nineRouterApiKeyImporterLoaded = true;

  const DEFAULT_SELECTORS = {
    connectButtonTexts: ["Add Connection", "OAuth", "Connect", "Add"],
    importModeTexts: ["Import Token"],
    refreshTokenLabelTexts: ["Refresh Token"],
    submitButtonTexts: ["Import Token"],
    successTextPatterns: ["success", "imported", "connected", "connection"],
    failureTextPatterns: ["local only", "cli token required", "failed", "invalid", "revoked", "expired", "unauthorized", "forbidden", "required", "error"],
    logoutTextPatterns: ["sign in", "login", "log in", "session expired"],
    connectButtonCss: [],
    refreshTokenInputCss: [
      'input[placeholder="Token will be auto-filled..."]',
      'input[type="text"]',
      "textarea"
    ],
    submitButtonCss: ["button"],
    overlayCss: ['[role="dialog"]', ".fixed", ".modal", ".dialog"],
    providerPathPattern: "/dashboard/providers/kiro"
  };

  const MESSAGE_TYPES = {
    VALIDATE_PAGE: "VALIDATE_PAGE",
    RUN_IMPORT_STEP: "RUN_IMPORT_STEP",
    IMPORT_RESULT: "IMPORT_RESULT"
  };

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalizeText(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function isVisible(element) {
    if (!element || !(element instanceof HTMLElement)) {
      return false;
    }

    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
      return false;
    }

    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function dedupeElements(elements) {
    return Array.from(new Set(elements.filter(Boolean)));
  }

  function getTextContent(element) {
    return normalizeText(
      element?.innerText ||
      element?.textContent ||
      element?.getAttribute?.("aria-label") ||
      element?.getAttribute?.("title") ||
      ""
    );
  }

  function maybeClickable(element) {
    if (!element) {
      return null;
    }

    if (element.matches?.("button, a, [role='button']")) {
      return element;
    }

    return element.closest?.("button, a, [role='button']") || element;
  }

  function gatherClickableCandidates(root = document) {
    return dedupeElements([
      ...root.querySelectorAll("button, a, [role='button'], span, div")
    ])
      .map(maybeClickable)
      .filter(isVisible);
  }

  function matchesText(targetText, patterns) {
    return (patterns || []).some((pattern) => {
      const normalizedPattern = normalizeText(pattern);
      return targetText === normalizedPattern || targetText.includes(normalizedPattern);
    });
  }

  function findButtonByTexts(patterns, root = document) {
    const candidates = gatherClickableCandidates(root);
    const exact = candidates.find((element) => {
      const text = getTextContent(element);
      return (patterns || []).some((pattern) => text === normalizeText(pattern));
    });

    if (exact) {
      return exact;
    }

    return candidates.find((element) => matchesText(getTextContent(element), patterns)) || null;
  }

  function findConnectButton(selectors) {
    const buttons = gatherClickableCandidates(document)
      .filter((element) => element.matches?.("button, [role='button']"));
    const ignoredTexts = ["get api key", "sign up", "learn more", "test", "edit", "delete"];
    const exact = buttons.find((element) => {
      const text = getTextContent(element);
      return (selectors.connectButtonTexts || []).some((pattern) => text === normalizeText(pattern));
    });

    if (exact) {
      return exact;
    }

    return buttons.find((element) => {
      const text = getTextContent(element);
      return matchesText(text, selectors.connectButtonTexts) &&
        !ignoredTexts.some((ignored) => text.includes(ignored));
    }) || null;
  }

  function findKiroImportModeButton(selectors, root = document) {
    const buttons = gatherClickableCandidates(root)
      .filter((element) => element.matches?.("button, [role='button']"));
    const uploadIconButton = buttons.find((button) => {
      const text = getTextContent(button);
      const iconText = normalizeText(button.querySelector?.(".material-symbols-outlined")?.textContent || "");
      return matchesText(text, selectors.importModeTexts) && iconText.includes("file_upload");
    });

    if (uploadIconButton) {
      return uploadIconButton;
    }

    const headingButton = Array.from(root.querySelectorAll("h1, h2, h3, h4, strong, p, span, div"))
      .map((element) => {
        const text = getTextContent(element);
        if (!matchesText(text, selectors.importModeTexts)) {
          return null;
        }

        return element.closest("button, [role='button']");
      })
      .find(isVisible);

    if (headingButton) {
      return headingButton;
    }

    return findButtonByTexts(selectors.importModeTexts, root);
  }

  function findElementByCss(selectors, root = document) {
    for (const selector of selectors || []) {
      const element = root.querySelector(selector);
      if (isVisible(element)) {
        return element;
      }
    }

    return null;
  }

  function getActiveOverlay(selectors) {
    for (const selector of selectors.overlayCss || []) {
      const overlays = Array.from(document.querySelectorAll(selector)).filter(isVisible);
      if (overlays.length) {
        return overlays[overlays.length - 1];
      }
    }

    return null;
  }

  function isInsideLabel(input, labels) {
    const previousLabel = input.closest("div")?.querySelector("label");
    const siblingText = normalizeText(previousLabel?.innerText || previousLabel?.textContent || "");
    return matchesText(siblingText, labels);
  }

  function findInputByLabel(labels, root = document) {
    const inputs = Array.from(root.querySelectorAll("input, textarea")).filter(isVisible);
    const exactLabel = Array.from(root.querySelectorAll("label")).find((label) => matchesText(getTextContent(label), labels));

    if (exactLabel) {
      const container = exactLabel.closest("div");
      const labelledInput = container?.querySelector("input, textarea");
      if (isVisible(labelledInput)) {
        return labelledInput;
      }
    }

    return inputs.find((input) => isInsideLabel(input, labels)) || null;
  }

  async function waitForElement(findFn, timeoutMs = 5000, intervalMs = 150) {
    const startedAt = Date.now();

    while (Date.now() - startedAt <= timeoutMs) {
      const element = findFn();
      if (element) {
        return element;
      }

      await sleep(intervalMs);
    }

    return null;
  }

  function clickElement(element) {
    if (!element) {
      return false;
    }

    element.scrollIntoView({ block: "center", inline: "center" });
    element.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true, cancelable: true, view: window }));
    element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    element.dispatchEvent(new MouseEvent("pointerup", { bubbles: true, cancelable: true, view: window }));
    element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    element.click();
    return true;
  }

  function setNativeValue(input, value) {
    const prototype = input instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");

    if (descriptor?.set) {
      descriptor.set.call(input, value);
      return;
    }

    input.value = value;
  }

  function fillInput(input, value) {
    input.focus();
    setNativeValue(input, "");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    setNativeValue(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function isProviderDetailPage(selectors) {
    return globalThis.location.pathname.includes(selectors.providerPathPattern || "/dashboard/providers/kiro");
  }

  function detectLogout(selectors) {
    const pageText = normalizeText(document.body?.innerText || "");
    return (selectors.logoutTextPatterns || []).some((pattern) => pageText.includes(normalizeText(pattern)));
  }

  function findErrorMessage(selectors, root = document) {
    const candidates = dedupeElements([
      ...root.querySelectorAll("[role='alert'], [role='status'], [aria-live], [class*='toast'], [class*='alert'], [class*='error'], p, div, span")
    ]).filter(isVisible);

    return candidates.find((element) => matchesText(getTextContent(element), selectors.failureTextPatterns || [])) || null;
  }

  function getReadableText(root = document, maxLength = 260) {
    return String(root?.innerText || root?.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, maxLength);
  }

  function findFailureText(selectors, root = document) {
    const text = getReadableText(root, 500);
    const normalized = normalizeText(text);
    const matchedPattern = (selectors.failureTextPatterns || [])
      .find((pattern) => normalized.includes(normalizeText(pattern)));

    if (!matchedPattern) {
      return "";
    }

    return text || `UI mengandung error: ${matchedPattern}`;
  }

  function findRefreshTokenInput(selectors, root = document) {
    return findInputByLabel(selectors.refreshTokenLabelTexts, root) ||
      findElementByCss(selectors.refreshTokenInputCss, root);
  }

  function getOpenImportOverlay(selectors) {
    const overlay = getActiveOverlay(selectors);

    if (!overlay) {
      return null;
    }

    return findRefreshTokenInput(selectors, overlay) ? overlay : null;
  }

  async function openImportOverlay(selectors) {
    const existingOverlay = getOpenImportOverlay(selectors);

    if (existingOverlay) {
      return existingOverlay;
    }

    const connectButton = await waitForElement(
      () => findConnectButton(selectors),
      8000,
      150
    );

    if (!connectButton) {
      throw new Error("Tombol Add Connection/OAuth tidak ditemukan.");
    }

    clickElement(connectButton);

    const overlay = await waitForElement(() => getActiveOverlay(selectors), 10000, 200);
    if (!overlay) {
      throw new Error("Modal Connect Kiro tidak terbuka.");
    }

    const importModeButton = await waitForElement(
      () => findKiroImportModeButton(selectors, getActiveOverlay(selectors) || overlay),
      8000,
      150
    );

    if (!importModeButton) {
      throw new Error("Pilihan Import Token tidak ditemukan.");
    }

    clickElement(importModeButton);

    const importOverlay = await waitForElement(() => getOpenImportOverlay(selectors), 8000, 200);
    if (!importOverlay) {
      throw new Error("Input Refresh Token tidak ditemukan.");
    }

    return importOverlay;
  }

  function isIgnorableAutoDetectFailure(message, selectors, root = document) {
    const normalized = normalizeText(message);
    const isCliTokenAutoDetectFailure = normalized.includes("local only") &&
      normalized.includes("cli token required");

    if (!isCliTokenAutoDetectFailure) {
      return false;
    }

    return Boolean(
      findRefreshTokenInput(selectors, root) &&
      findButtonByTexts(selectors.submitButtonTexts, root)
    );
  }

  async function waitForImportOutcome(selectors, previousOverlay, timeoutMs, ignoredInitialText = "") {
    const startedAt = Date.now();
    const ignoredNormalizedText = normalizeText(ignoredInitialText);

    while (Date.now() - startedAt <= timeoutMs) {
      if (detectLogout(selectors)) {
        return { status: "failed", message: "Session login terdeteksi hilang." };
      }

      const currentOverlay = getActiveOverlay(selectors);
      if (!currentOverlay || currentOverlay !== previousOverlay || !document.body.contains(previousOverlay)) {
        return { status: "success", message: "Connection berhasil disimpan." };
      }

      const errorMessage = findErrorMessage(selectors, currentOverlay);
      if (errorMessage) {
        const message = errorMessage.innerText.trim() || "UI menampilkan error.";
        const normalizedMessage = normalizeText(message);

        if (ignoredNormalizedText && normalizedMessage && ignoredNormalizedText.includes(normalizedMessage) && Date.now() - startedAt < 2000) {
          await sleep(250);
          continue;
        }

        if (isIgnorableAutoDetectFailure(message, selectors, currentOverlay)) {
          await sleep(250);
          continue;
        }

        return {
          status: "failed",
          message
        };
      }

      const failureText = findFailureText(selectors, currentOverlay);
      if (failureText) {
        const normalizedFailureText = normalizeText(failureText);

        if (ignoredNormalizedText && normalizedFailureText && ignoredNormalizedText.includes(normalizedFailureText) && Date.now() - startedAt < 2000) {
          await sleep(250);
          continue;
        }

        if (isIgnorableAutoDetectFailure(failureText, selectors, currentOverlay)) {
          await sleep(250);
          continue;
        }

        return {
          status: "failed",
          message: failureText
        };
      }

      await sleep(250);
    }

    return {
      status: "failed",
      message: `Tidak ada sinyal hasil UI yang dapat diverifikasi setelah Import Token. Modal: ${getReadableText(previousOverlay)}`
    };
  }

  async function validatePage(payload) {
    const selectors = { ...DEFAULT_SELECTORS, ...(payload?.selectors || {}) };

    if (!isProviderDetailPage(selectors)) {
      return {
        ok: false,
        error: "Tab aktif harus berada di halaman /dashboard/providers/kiro."
      };
    }

    const connectButton = await waitForElement(
      () => findConnectButton(selectors),
      8000,
      150
    );

    if (!connectButton) {
      return {
        ok: false,
        error: "Tombol Add Connection/OAuth tidak ditemukan di halaman provider Kiro."
      };
    }

    return { ok: true };
  }

  async function runImportStep(payload) {
    const selectors = { ...DEFAULT_SELECTORS, ...(payload?.selectors || {}) };
    const settings = payload?.settings || {};
    const timeoutMs = settings.stepTimeoutMs || 8000;
    const item = payload?.item;

    if (!item?.id || !item.credential) {
      return { ok: false, error: "Queue item tidak valid." };
    }

    if (!isProviderDetailPage(selectors)) {
      return { ok: false, error: "Halaman aktif bukan /dashboard/providers/kiro." };
    }

    if (detectLogout(selectors)) {
      return { ok: false, error: "Session login tidak valid." };
    }

    let overlay;

    try {
      overlay = await openImportOverlay(selectors);
    } catch (error) {
      return { ok: false, error: error.message };
    }

    const refreshTokenInput = await waitForElement(
      () => findRefreshTokenInput(selectors, getActiveOverlay(selectors) || overlay),
      8000,
      200
    );

    if (!refreshTokenInput) {
      return { ok: false, error: "Input Refresh Token tidak ditemukan." };
    }

    fillInput(refreshTokenInput, item.credential);
    await sleep(100);

    const currentOverlay = getActiveOverlay(selectors) || overlay;
    const initialOverlayText = getReadableText(currentOverlay, 500);
    const submitButton = await waitForElement(
      () => findButtonByTexts(selectors.submitButtonTexts, getActiveOverlay(selectors) || currentOverlay) || findElementByCss(selectors.submitButtonCss, getActiveOverlay(selectors) || currentOverlay),
      2500,
      150
    );

    if (!submitButton) {
      return { ok: false, error: "Tombol Import Token tidak ditemukan." };
    }

    clickElement(submitButton);
    await sleep(500);
    const outcome = await waitForImportOutcome(selectors, currentOverlay, timeoutMs, initialOverlayText);

    chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.IMPORT_RESULT,
      payload: {
        id: item.id,
        status: outcome.status,
        message: outcome.message
      }
    }, () => {
      void chrome.runtime.lastError;
    });

    return { ok: true };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === MESSAGE_TYPES.VALIDATE_PAGE) {
      validatePage(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }

    if (message?.type === MESSAGE_TYPES.RUN_IMPORT_STEP) {
      runImportStep(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }

    return false;
  });
})();
