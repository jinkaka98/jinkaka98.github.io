# 9Router Kiro Token Batch Importer

Chrome Extension Manifest V3 untuk batch import refresh token Kiro ke halaman provider Kiro di 9Router.

## Flow MVP

1. Buka 9Router di tab aktif, misalnya `http://localhost:20128/dashboard`.
2. Klik icon extension.
3. Paste refresh token mentah ke textarea, satu token per baris.
4. Format bisa langsung seperti file contoh `aorAAAAAG...:MGQCM...`.
5. Jika endpoint berubah, isi `Endpoint 9Router`, misalnya `https://router2.alpakyros.com`, klik `Simpan`, lalu `Cek endpoint`.
6. Klik tombol utama `Start Import`.
7. Extension otomatis membuka `/dashboard/providers/kiro`, lalu menjalankan flow `Add Connection/OAuth -> Import Token -> isi Refresh Token -> Import Token`.
8. Saat proses berjalan, tombol utama berubah menjadi `Stop Import`; klik tombol yang sama untuk menghentikan proses.
9. Gunakan `Hapus cepat` untuk mengosongkan textarea sebelum paste batch baru.
10. Lihat `Log history` untuk menangkap error per token, termasuk pesan UI seperti `Local only: CLI token required`.

## Load di Chrome

1. Buka `chrome://extensions`.
2. Aktifkan `Developer mode`.
3. Klik `Load unpacked`.
4. Pilih folder `chrome-extension` di dalam repo ini.

## Settings Default

- `baseUrl`: `http://localhost:20128`
- `allowedUrlPattern`: `http://localhost:20128/*`
- `providerPath`: `/dashboard/providers/kiro`
- `autoNavigateToProvider`: `true`
- `stepTimeoutMs`: `8000`
- `betweenItemsDelayMs`: `1200`
- `retryLimit`: `0`
- `pauseOnFailure`: `false`

## Catatan Penting

- MVP otomatis membuka halaman provider Kiro dari tab 9Router aktif.
- Jika tab aktif bukan host 9Router yang diizinkan, Start tetap ditolak.
- Textarea menerima isi file contoh langsung: satu refresh token mentah per baris.
- Jika modal tidak tertutup atau UI menampilkan error setelah `Import Token`, item dianggap gagal.
- Log history disimpan di storage lokal dan bisa dihapus dari popup.
