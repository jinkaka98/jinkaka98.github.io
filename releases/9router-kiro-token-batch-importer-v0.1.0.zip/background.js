import {
  ALARM_NAMES,
  MESSAGE_TYPES,
  SESSION_STATUSES
} from "./lib/constants.js";
import {
  createCompletedSession,
  createIdleSession,
  createRunningSession
} from "./lib/defaults.js";
import { buildRuntimeConfig } from "./lib/router-config.js";
import {
  ensureDefaults,
  getState,
  getSettings,
  saveSessionState,
  setDraftInput
} from "./lib/storage.js";

function sendTabMessage(tabId, message, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error("Timed out waiting for content script response."));
    }, timeoutMs);

    chrome.tabs.sendMessage(tabId, message, (response) => {
      clearTimeout(timer);
      const error = chrome.runtime.lastError;

      if (error) {
        reject(new Error(error.message));
        return;
      }

      resolve(response);
    });
  });
}

function sendRuntimeUpdate() {
  chrome.runtime.sendMessage({ type: MESSAGE_TYPES.SESSION_UPDATE }, () => {
    void chrome.runtime.lastError;
  });
}

function escapeForRegex(value) {
  return value.replace(/[|\\{}()[\]^$+?.]/g, "\\$&");
}

function wildcardToRegex(pattern) {
  const escaped = escapeForRegex(pattern).replace(/\*/g, ".*");
  return new RegExp(`^${escaped}$`);
}

function matchesAllowedUrl(url, pattern) {
  if (!url || !pattern) {
    return false;
  }

  return wildcardToRegex(pattern).test(url);
}

function normalizePath(path) {
  const value = String(path || "").trim();

  if (!value) {
    return "/dashboard/providers/kiro";
  }

  return value.startsWith("/") ? value : `/${value}`;
}

function buildProviderUrl(settings) {
  const base = new URL(settings.baseUrl);
  base.pathname = normalizePath(settings.providerPath);
  base.search = "";
  base.hash = "";
  return base.toString();
}

function isProviderUrl(url, settings) {
  try {
    const parsed = new URL(url);
    return parsed.pathname.includes(normalizePath(settings.providerPath));
  } catch {
    return false;
  }
}

function credentialPreview(credential) {
  if (!credential) {
    return "";
  }

  if (credential.length <= 18) {
    return credential;
  }

  return `${credential.slice(0, 10)}...${credential.slice(-6)}`;
}

function createQueueItems(credentials) {
  const prefix = Date.now();

  return credentials.map((credential, index) => ({
    id: `${prefix}-${index + 1}`,
    name: credential.name || `Key ${index + 1}`,
    credential: credential.credential,
    raw: credential.raw || credential.credential,
    status: "queued",
    attempt: 0,
    startedAt: null,
    finishedAt: null,
    lastError: null
  }));
}

function createHistoryEntry(level, message, details = {}) {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    level,
    message,
    details,
    createdAt: new Date().toISOString()
  };
}

function appendHistory(state, entry) {
  return [
    entry,
    ...(Array.isArray(state.history) ? state.history : [])
  ].slice(0, 120);
}

async function clearAutomationAlarms() {
  await chrome.alarms.clear(ALARM_NAMES.PROCESS_NEXT);
  await chrome.alarms.clear(ALARM_NAMES.ITEM_TIMEOUT);
}

async function injectContentScript(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content-script.js"]
  });
}

function originPatternFromBaseUrl(baseUrl) {
  const parsed = new URL(baseUrl);
  return `${parsed.protocol}//${parsed.host}/*`;
}

async function ensureOriginPermission(baseUrl) {
  const origin = originPatternFromBaseUrl(baseUrl);
  const contains = await chrome.permissions.contains({ origins: [origin] });

  if (contains) {
    return;
  }

  throw new Error(`Host permission belum diberikan untuk ${origin}. Klik Start dari popup untuk mengizinkan akses host.`);
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function waitForTabComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Timeout menunggu halaman provider Kiro selesai dimuat."));
    }, timeoutMs);

    function listener(updatedTabId, changeInfo, tab) {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") {
        return;
      }

      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    }

    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function navigateToProviderIfNeeded(tab, settings) {
  if (isProviderUrl(tab.url, settings)) {
    return tab;
  }

  if (!settings.autoNavigateToProvider) {
    throw new Error(`Tab aktif belum di halaman ${normalizePath(settings.providerPath)}.`);
  }

  const providerUrl = buildProviderUrl(settings);
  const updatedTab = await chrome.tabs.update(tab.id, { url: providerUrl, active: true });

  try {
    await waitForTabComplete(tab.id);
  } catch {
    // React apps can still be ready after the navigation timeout; read the tab and let preflight decide.
  }

  return chrome.tabs.get(updatedTab.id);
}

async function readValidTargetTab(settings, expectedTabId, options = {}) {
  let tab;

  if (expectedTabId) {
    try {
      tab = await chrome.tabs.get(expectedTabId);
    } catch {
      tab = null;
    }
  }

  if (!tab) {
    tab = await getActiveTab();
  }

  if (!tab?.id || !tab.url) {
    throw new Error("Tab aktif 9Router tidak ditemukan.");
  }

  if (options.ensureProvider) {
    tab = await navigateToProviderIfNeeded(tab, settings);
  }

  if (!matchesAllowedUrl(tab.url, settings.allowedUrlPattern)) {
    throw new Error(`Tab target tidak cocok dengan allowedUrlPattern: ${settings.allowedUrlPattern}. URL sekarang: ${tab.url}`);
  }

  return tab;
}

async function scheduleNextProcess(delayMs) {
  await chrome.alarms.create(ALARM_NAMES.PROCESS_NEXT, {
    when: Date.now() + Math.max(0, delayMs)
  });
}

async function scheduleItemTimeout(timeoutMs) {
  await chrome.alarms.create(ALARM_NAMES.ITEM_TIMEOUT, {
    when: Date.now() + Math.max(1000, timeoutMs)
  });
}

async function updateState(state) {
  await saveSessionState(state);
  sendRuntimeUpdate();
}

async function markSessionError(message) {
  const state = await getState();
  const historyEntry = createHistoryEntry("error", message, {
    targetUrl: state.session.targetUrl || ""
  });
  const nextState = {
    ...state,
    history: appendHistory(state, historyEntry),
    session: {
      ...state.session,
      status: SESSION_STATUSES.ERROR,
      currentError: message,
      currentItemId: null,
      currentCredentialPreview: "",
      updatedAt: new Date().toISOString()
    }
  };

  await clearAutomationAlarms();
  await updateState(nextState);
}

async function finalizeItem(itemId, status, message) {
  const state = await getState();
  const { queue, results, session, settings } = state;
  const processedAt = new Date().toISOString();
  const existingItem = queue.find((item) => item.id === itemId);

  if (!existingItem || existingItem.status !== "processing") {
    return;
  }

  const nextQueue = queue.map((item) => {
    if (item.id !== itemId) {
      return item;
    }

    return {
      ...item,
      status,
      finishedAt: processedAt,
      lastError: status === "failed" ? message : null
    };
  });

  const processedItem = nextQueue.find((item) => item.id === itemId);
  const historyEntry = createHistoryEntry(status === "success" ? "success" : "error", message, {
    itemId,
    credentialPreview: credentialPreview(processedItem?.credential),
    attempt: processedItem?.attempt || 0,
    targetUrl: session.targetUrl || ""
  });

  const nextResults = [
    ...results,
    {
      id: itemId,
      credentialPreview: credentialPreview(processedItem?.credential),
      status,
      message,
      processedAt
    }
  ];

  const activeProcessing = nextQueue.find((item) => item.status === "processing");
  const queuedLeft = nextQueue.filter((item) => item.status === "queued").length;
  const successCount = nextResults.filter((item) => item.status === "success").length;
  const failedCount = nextResults.filter((item) => item.status === "failed").length;

  let nextSession = {
    ...session,
    currentItemId: null,
    currentCredentialPreview: "",
    currentError: status === "failed" ? message : "",
    successCount,
    failedCount,
    processedCount: successCount + failedCount,
    updatedAt: processedAt
  };

  if (session.stopRequested) {
    nextSession = createIdleSession({
      ...nextSession,
      targetTabId: session.targetTabId,
      targetUrl: session.targetUrl,
      successCount,
      failedCount,
      processedCount: successCount + failedCount
    });
  } else if (status === "failed" && settings.pauseOnFailure) {
    nextSession.status = SESSION_STATUSES.PAUSED;
  } else if (!queuedLeft && !activeProcessing) {
    nextSession = createCompletedSession({
      ...nextSession,
      totalCount: session.totalCount,
      targetTabId: session.targetTabId,
      targetUrl: session.targetUrl,
      successCount,
      failedCount,
      processedCount: successCount + failedCount
    });
  } else if (session.status === SESSION_STATUSES.PAUSED) {
    nextSession.status = SESSION_STATUSES.PAUSED;
  } else {
    nextSession.status = SESSION_STATUSES.RUNNING;
  }

  const nextState = {
    ...state,
    queue: nextQueue,
    results: nextResults,
    history: appendHistory(state, historyEntry),
    session: nextSession
  };

  await chrome.alarms.clear(ALARM_NAMES.ITEM_TIMEOUT);
  await updateState(nextState);

  if (nextSession.status === SESSION_STATUSES.RUNNING) {
    await scheduleNextProcess(settings.betweenItemsDelayMs);
  }
}

async function cancelActiveItem(message = "Import dihentikan oleh user.") {
  const state = await getState();
  const activeItem = state.queue.find((item) => item.status === "processing");

  if (!activeItem) {
    return false;
  }

  const processedAt = new Date().toISOString();
  const nextQueue = state.queue.map((item) => {
    if (item.id !== activeItem.id) {
      return item;
    }

    return {
      ...item,
      status: "failed",
      finishedAt: processedAt,
      lastError: message
    };
  });
  const nextResults = [
    ...state.results,
    {
      id: activeItem.id,
      credentialPreview: credentialPreview(activeItem.credential),
      status: "failed",
      message,
      processedAt
    }
  ];
  const historyEntry = createHistoryEntry("warn", message, {
    itemId: activeItem.id,
    credentialPreview: credentialPreview(activeItem.credential),
    targetUrl: state.session.targetUrl || ""
  });
  const successCount = nextResults.filter((item) => item.status === "success").length;
  const failedCount = nextResults.filter((item) => item.status === "failed").length;

  await clearAutomationAlarms();
  await updateState({
    ...state,
    queue: nextQueue,
    results: nextResults,
    history: appendHistory(state, historyEntry),
    session: createIdleSession({
      ...state.session,
      targetTabId: state.session.targetTabId,
      targetUrl: state.session.targetUrl,
      currentItemId: null,
      currentCredentialPreview: "",
      currentError: "",
      successCount,
      failedCount,
      processedCount: successCount + failedCount,
      stopRequested: false
    })
  });

  return true;
}

async function processNextItem() {
  const state = await getState();
  const { queue, session, settings } = state;

  if (session.status !== SESSION_STATUSES.RUNNING) {
    return;
  }

  if (queue.some((item) => item.status === "processing")) {
    return;
  }

  const nextItem = queue.find((item) => item.status === "queued");

  if (!nextItem) {
    const nextState = {
      ...state,
      session: createCompletedSession({
        ...session,
        updatedAt: new Date().toISOString()
      })
    };

    await updateState(nextState);
    return;
  }

  let tab;

  try {
    tab = await readValidTargetTab(settings, session.targetTabId, { ensureProvider: true });
    await injectContentScript(tab.id);
  } catch (error) {
    await finalizeItem(nextItem.id, "failed", error.message);
    return;
  }

  const startedAt = new Date().toISOString();
  const nextQueue = queue.map((item) => {
    if (item.id !== nextItem.id) {
      return item;
    }

    return {
      ...item,
      status: "processing",
      attempt: item.attempt + 1,
      startedAt
    };
  });

  const nextSession = {
    ...session,
    status: SESSION_STATUSES.RUNNING,
    targetTabId: tab.id,
    targetUrl: tab.url,
    currentItemId: nextItem.id,
    currentCredentialPreview: credentialPreview(nextItem.credential),
    currentError: "",
    updatedAt: startedAt
  };

  await updateState({
    ...state,
    queue: nextQueue,
    session: nextSession,
    history: appendHistory(state, createHistoryEntry("info", "Memproses refresh token.", {
      itemId: nextItem.id,
      credentialPreview: credentialPreview(nextItem.credential),
      attempt: nextItem.attempt + 1,
      targetUrl: tab.url
    }))
  });

  await scheduleItemTimeout(settings.stepTimeoutMs + 2000);

  try {
    const runtimeConfig = buildRuntimeConfig(settings);
    const response = await sendTabMessage(tab.id, {
      type: MESSAGE_TYPES.RUN_IMPORT_STEP,
      payload: {
        item: {
          ...nextItem,
          attempt: nextItem.attempt + 1
        },
        settings,
        selectors: runtimeConfig
      }
    }, settings.stepTimeoutMs + 5000);

    if (!response?.ok) {
      await finalizeItem(nextItem.id, "failed", response?.error || "Content script menolak request import.");
    }
  } catch (error) {
    await finalizeItem(nextItem.id, "failed", error.message);
  }
}

async function preflightStart(settings, tabId) {
  await injectContentScript(tabId);
  const response = await sendTabMessage(tabId, {
    type: MESSAGE_TYPES.VALIDATE_PAGE,
    payload: {
      settings,
      selectors: buildRuntimeConfig(settings)
    }
  });

  if (!response?.ok) {
    throw new Error(response?.error || "Halaman provider belum siap.");
  }
}

async function startImport(credentials) {
  if (!credentials?.length) {
    throw new Error("Refresh token batch kosong.");
  }

  const startState = await getState();
  const settings = startState.settings;
  const tab = await readValidTargetTab(settings, null, { ensureProvider: true });

  await ensureOriginPermission(settings.baseUrl);
  await preflightStart(settings, tab.id);

  const queue = createQueueItems(credentials);
  const session = createRunningSession({
    totalCount: queue.length,
    targetTabId: tab.id,
    targetUrl: tab.url
  });

  await clearAutomationAlarms();
  await updateState({
    settings,
    draftInput: credentials.map((item) => item.raw || item.credential).join("\n"),
    queue,
    results: [],
    history: appendHistory(startState, createHistoryEntry("info", `Import dimulai: ${queue.length} refresh token.`, {
      total: queue.length,
      targetUrl: tab.url
    })),
    session
  });

  await processNextItem();
}

async function resumeImport() {
  const state = await getState();
  const { queue, session, settings } = state;

  if (!queue.some((item) => item.status === "queued")) {
    throw new Error("Tidak ada item queued untuk di-resume.");
  }

  const tab = await readValidTargetTab(settings, session.targetTabId, { ensureProvider: true });
  await ensureOriginPermission(settings.baseUrl);
  await preflightStart(settings, tab.id);

  const nextSession = {
    ...session,
    status: SESSION_STATUSES.RUNNING,
    stopRequested: false,
    targetTabId: tab.id,
    targetUrl: tab.url,
    currentError: "",
    updatedAt: new Date().toISOString()
  };

  await clearAutomationAlarms();
  await updateState({
    ...state,
    session: nextSession
  });

  await processNextItem();
}

async function pauseImport() {
  const state = await getState();

  await chrome.alarms.clear(ALARM_NAMES.PROCESS_NEXT);

  const nextState = {
    ...state,
    session: {
      ...state.session,
      status: SESSION_STATUSES.PAUSED,
      updatedAt: new Date().toISOString()
    }
  };

  await updateState(nextState);
}

async function stopImport() {
  const state = await getState();
  const hasProcessing = state.queue.some((item) => item.status === "processing");
  const stoppedAt = new Date().toISOString();

  await clearAutomationAlarms();

  if (hasProcessing) {
    await cancelActiveItem();
    return;
  }

  const stoppedQueuedItems = state.queue.filter((item) => item.status === "queued");
  const stoppedResults = stoppedQueuedItems.map((item) => ({
    id: item.id,
    credentialPreview: credentialPreview(item.credential),
    status: "failed",
    message: "Import dihentikan oleh user.",
    processedAt: stoppedAt
  }));
  const stoppedHistoryEntries = stoppedQueuedItems.map((item) => createHistoryEntry("warn", "Queued item dihentikan oleh user.", {
    itemId: item.id,
    credentialPreview: credentialPreview(item.credential),
    targetUrl: state.session.targetUrl || ""
  }));
  const nextResults = [...state.results, ...stoppedResults];
  const successCount = nextResults.filter((item) => item.status === "success").length;
  const failedCount = nextResults.filter((item) => item.status === "failed").length;

  const nextSession = createIdleSession({
    ...state.session,
    currentItemId: null,
    currentCredentialPreview: "",
    currentError: "",
    successCount,
    failedCount,
    processedCount: successCount + failedCount,
    targetTabId: state.session.targetTabId,
    targetUrl: state.session.targetUrl,
    stopRequested: false
  });

  await updateState({
    ...state,
    queue: state.queue.map((item) => item.status === "queued"
      ? {
          ...item,
          status: "failed",
          finishedAt: stoppedAt,
          lastError: "Import dihentikan oleh user."
        }
      : item),
    results: nextResults,
    history: [
      createHistoryEntry("warn", "Import dihentikan oleh user.", {
        stoppedQueuedCount: stoppedQueuedItems.length,
        targetUrl: state.session.targetUrl || ""
      }),
      ...stoppedHistoryEntries,
      ...(Array.isArray(state.history) ? state.history : [])
    ].slice(0, 120),
    session: nextSession
  });
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaults().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  ensureDefaults().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    await ensureDefaults();

    switch (message?.type) {
      case MESSAGE_TYPES.START_IMPORT:
        await setDraftInput((message.payload?.credentials || []).map((item) => item.raw || item.credential).join("\n"));
        await startImport(message.payload?.credentials || []);
        sendResponse({ ok: true });
        return;
      case MESSAGE_TYPES.RESUME_IMPORT:
        await resumeImport();
        sendResponse({ ok: true });
        return;
      case MESSAGE_TYPES.PAUSE_IMPORT:
        await pauseImport();
        sendResponse({ ok: true });
        return;
      case MESSAGE_TYPES.STOP_IMPORT:
        await stopImport();
        sendResponse({ ok: true });
        return;
      case MESSAGE_TYPES.IMPORT_RESULT:
        await finalizeItem(
          message.payload?.id,
          message.payload?.status === "success" ? "success" : "failed",
          message.payload?.message || "Import selesai tanpa pesan hasil."
        );
        sendResponse({ ok: true });
        return;
      case MESSAGE_TYPES.CLEAR_HISTORY: {
        const state = await getState();
        await updateState({
          ...state,
          history: []
        });
        sendResponse({ ok: true });
        return;
      }
      default:
        sendResponse({ ok: false, error: "Unsupported message type." });
    }
  })().catch((error) => {
    sendResponse({ ok: false, error: error.message });
  });

  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  (async () => {
    if (alarm.name === ALARM_NAMES.PROCESS_NEXT) {
      await processNextItem();
      return;
    }

    if (alarm.name === ALARM_NAMES.ITEM_TIMEOUT) {
      const state = await getState();
      const activeItem = state.queue.find((item) => item.status === "processing");

      if (activeItem) {
        await finalizeItem(activeItem.id, "failed", "Timeout menunggu sinyal hasil UI.");
      }
    }
  })().catch((error) => {
    markSessionError(error.message).catch(() => {});
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  (async () => {
    const state = await getState();

    if (state.session.targetTabId === tabId && state.session.status === SESSION_STATUSES.RUNNING) {
      await markSessionError("Tab target ditutup saat automation berjalan.");
    }
  })().catch(() => {});
});
